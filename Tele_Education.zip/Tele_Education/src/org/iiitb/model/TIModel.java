package org.iiitb.model;

public class TIModel {
private int TI_ID;
private String TI_NAME;
public int getTI_ID() {
	return TI_ID;
}
public void setTI_ID(int tI_ID) {
	TI_ID = tI_ID;
}
public String getTI_NAME() {
	return TI_NAME;
}
public void setTI_NAME(String tI_NAME) {
	TI_NAME = tI_NAME;
}

}
