package org.iiitb.model;

public class SolveIssueModel {
	private String urissueid;
	
	
	public String getUrissueid() {
		return urissueid;
	}
	public void setUrissueid(String urissueid) {
		this.urissueid = urissueid;
	}
	
	
	
	
}
