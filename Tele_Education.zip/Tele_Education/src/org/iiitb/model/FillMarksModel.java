package org.iiitb.model;

import java.util.ArrayList;

public class FillMarksModel {
	
	
	ArrayList<Integer> marks=new ArrayList<Integer>();

	public ArrayList<Integer> getMarks() {
		return marks;
	}

	public void setMarks(ArrayList<Integer> marks) {
		this.marks = marks;
	}
	

}
