package org.iiitb.action;

public class AddStudent {
	
	
	
	public String execute() throws Exception
	{
		
		return "success";
	}

}
