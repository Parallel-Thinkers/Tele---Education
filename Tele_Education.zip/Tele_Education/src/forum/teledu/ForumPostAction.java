package forum.teledu;

public class ForumPostAction {

}
